import React from 'react';
import { render } from 'react-dom';
import { Router, Route, IndexRoute, browserHistory } from 'react-router';

import { App } from '../../ui/layouts/app.jsx';
import { Index } from '../../ui/components/index.jsx';

import { AboutUs } from '../../ui/pages/about_us.js';
import { ContactUs } from '../../ui/pages/contact_us.js';

Meteor.startup( () => {
  render(
    <Router history={ browserHistory }>
      <Route path="/" component={ App }>
        <IndexRoute component={ Index } />
        <Route path="/about_us" component={ AboutUs } />
        <Route path="/contact_us" component={ ContactUs } />
      </Route>
    </Router>,
    document.querySelector( '.art-content-layout' )
  );
});
