import React from 'react';
import { Tasks } from '../../collections/descriptions';
import ImageDetail from './image_detail';
import ContentDetail from './content_detail';

export const AboutUs = () => {

	//console.log( Tasks.find({}).fetch() );
	
	const RenderedImages = Tasks.find({}).fetch().map( function( image ){
			return (
				<div className="art-content-layout-row">
					<ImageDetail key={image._id} image={image} />
					<ContentDetail image={image} />
				</div>
				);
	});

	return (
		<div>
			{ RenderedImages }
		</div>
		);
}

//console.log( Tasks.find({}).fetch() );