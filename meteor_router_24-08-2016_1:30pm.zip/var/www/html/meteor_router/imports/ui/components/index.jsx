import React from 'react';

export const Index = () => <h3>Home</h3>;